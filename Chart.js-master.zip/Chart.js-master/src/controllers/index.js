export {default as bar} from './controller.bar';
export {default as bubble} from './controller.bubble';
export {default as doughnut} from './controller.doughnut';
export {default as line} from './controller.line';
export {default as polarArea} from './controller.polarArea';
export {default as pie} from './controller.pie';
export {default as radar} from './controller.radar';
export {default as scatter} from './controller.scatter';

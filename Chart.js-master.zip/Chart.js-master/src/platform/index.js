export {default as BasePlatform} from './platform.base';
export {default as BasicPlatform} from './platform.basic';
export {default as DomPlatform} from './platform.dom';
